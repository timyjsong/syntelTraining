package rms.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import rms.mapper.VisitorsMapper;
import rms.model.VisitorsModel;

import java.util.List;

public class VisitorDAO {
    private JdbcTemplate temp;
    private ApplicationContext context;

    public VisitorDAO(){
        context = new ClassPathXmlApplicationContext("spring-config.xml"); 
        temp = (JdbcTemplate) context.getBean("jt");
    }
    
    // Return VisitorModel with specified visitorID
    public VisitorsModel getVisitor(int visId) {
    	return (VisitorsModel)temp.queryForObject("Select * from Visitor where visId = ?", new VisitorsMapper(), visId);
    }
    
    // Inserts specified visitor into Visitor table
    public int insertVisitor(VisitorsModel vis) {
    	return temp.update("insert into Visitor values(?,?,?,?,?,?,?)",
    			vis.getvisId(), vis.getVisName(), vis.getVisEmail(), vis.getVisPhone(), 
    			vis.getBadgeId(), vis.getVisPurpose(), vis.getVisCompany());
    }
	
    // Updates isActive column entry to 0 to the specified visitor from Visitor table
    public int deleteVisitor(VisitorsModel vis) {
    	return temp.update("update Visitor set isActive = ? where visId = ?", 0, vis.getvisId());
    }
	
    // Updates specified visitor from Visitor table
    public int updateVisitor(VisitorsModel vis) {
    	return temp.update("update Visitor set visName = ?, visEmail = ?, visPhone = ?, "
    			+ "badgeId = ?, visPurpose = ?, visCompany = ? where visId = ?)",
    			vis.getVisName(), vis.getVisEmail(), vis.getVisPhone(), vis.getBadgeId(),
    			vis.getVisPurpose(), vis.getVisCompany(), vis.getvisId());
    }
    
    // Returns a list of VisitorModel from Visitor table
    public List<VisitorsModel> getAllVisitors() {
    	return temp.query("select * from Visitor", new VisitorsMapper());
    }

}
