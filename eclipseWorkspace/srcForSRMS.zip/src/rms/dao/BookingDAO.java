package rms.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import rms.model.BookingModel;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BookingDAO {
    private JdbcTemplate temp;
    private ApplicationContext context;

    public BookingDAO(){
        context = new ClassPathXmlApplicationContext("spring-config.xml");
        temp = (JdbcTemplate) context.getBean("jt");
    }
    public List<ChartData> getNumberBookingPerDay()
    {
        List<ChartData> data = new ArrayList<>();
        List<Map<String, Object>> rows = temp.queryForList("SELECT Trunc(starttime) as dt,COUNT(*) as cnt FROM BOOKING GROUP BY STARTTIME");
        for (Map row: rows) {
            ChartData temp = new ChartData();
            temp.setNumDays(((BigDecimal)row.get("cnt")).intValue());
            temp.setDateTime(((Timestamp)row.get("dt")).toLocalDateTime().toLocalDate().toString());
            data.add(temp);
        }
        return data;
    }
    public void insert(BookingModel model)
    {

    }
    public void update(int ID, BookingModel model)
    {

    }
    public void remove(int ID)
    {

    }
    public BookingModel get(int ID)
    {
        return new BookingModel();
    }
    public List<BookingModel> getALL()
    {
        return new ArrayList<>();
    }
}
